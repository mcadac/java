

1. wget https://sourceforge.net/projects/jsch/files/jsch.jar/0.1.55/jsch-0.1.55.jar
2. Create the java file with the code
3. javac -classpath ".:jsch-0.1.55.jar" JSchExampleSSHConnection.java
4. Once it is compiled, it will generate a class file
5. To execute it, run the following command
	java -classpath ".:jsch-0.1.55.jar" JSchExampleSSHConnection
